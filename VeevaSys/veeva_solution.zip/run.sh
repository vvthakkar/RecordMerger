java -cp cantest.jar:lib/* RecordMerger $*

